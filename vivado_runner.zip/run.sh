#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INTERNAL_ROOT="$SCRIPT_DIR/vivado_runner"
DEFAULT_FLOW_CONFIG="$SCRIPT_DIR/flow_config"
CLEAN_SCRIPT="$SCRIPT_DIR/clean.sh"

source "$INTERNAL_ROOT/lib/bash/common.sh"
source "$INTERNAL_ROOT/lib/bash/args.sh"
source "$INTERNAL_ROOT/lib/bash/config.sh"
source "$INTERNAL_ROOT/lib/bash/discover.sh"
source "$INTERNAL_ROOT/lib/bash/judge.sh"
source "$INTERNAL_ROOT/lib/bash/worker.sh"
source "$INTERNAL_ROOT/lib/bash/scheduler.sh"
source "$INTERNAL_ROOT/lib/bash/report.sh"
source "$INTERNAL_ROOT/lib/bash/copy.sh"

main() {
    trap 'handle_interrupt' INT TERM

    parse_args "$@"

    if [ -z "${FLOW_CONFIG_PATH:-}" ]; then
        FLOW_CONFIG_PATH="$DEFAULT_FLOW_CONFIG"
    fi

    # Run clean.sh before creating runtime directories.
    if [ -f "$CLEAN_SCRIPT" ]; then
        log_info "Running clean script: $CLEAN_SCRIPT"
        (
            cd "$SCRIPT_DIR"
            bash "$CLEAN_SCRIPT"
        )
    else
        log_error "clean.sh not found: $CLEAN_SCRIPT"
        exit 1
    fi

    init_runtime_dirs

    load_default_config
    apply_cli_overrides
    load_flow_config
    validate_runtime_config

    log_info "Workspace root: $SCRIPT_DIR"
    log_info "Input target: $INPUT_TARGET"
    log_info "Flow config: $FLOW_CONFIG_ABS"
    log_info "Runtime root: $RUNTIME_DIR"

    discover_cases "$INPUT_TARGET"

    local case_count
    case_count=$(count_cases)
    if [ "$case_count" -le 0 ]; then
        log_error "No valid run.tcl cases found"
        exit 1
    fi

    log_info "Discovered $case_count case(s)"

    if [ "$ENABLE_COPY_REPORTS" -eq 1 ]; then
        init_live_report_dir
    fi

    dispatch_cases
    finalize_reports

    if [ "$ENABLE_COPY_REPORTS" -eq 1 ]; then
        copy_summary_reports
    else
        log_info "Skip copying reports. Use --copy to export final summary."
    fi

    print_final_summary
}

main "$@"
exit 0